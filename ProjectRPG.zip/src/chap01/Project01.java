package chap01;

public class Project01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameStart.Start();
		ItemUse3.PassiveItem();
		User.showMenu();

	}

}
